package com.anubhavauth.medisyncbackend.entities.enums;

public enum Roles {
    ADMIN,
    PATIENT,
    DOCTOR,
    HOSPITAL_STAFF
}
