package com.anubhavauth.medisyncbackend.repository;

import com.anubhavauth.medisyncbackend.entities.persistentEntities.Appointments;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface AppointmentRepository extends MongoRepository<Appointments, ObjectId> {
}
