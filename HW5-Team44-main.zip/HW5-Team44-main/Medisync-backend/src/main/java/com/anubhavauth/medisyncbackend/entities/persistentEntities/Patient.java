package com.anubhavauth.medisyncbackend.entities.persistentEntities;


import com.anubhavauth.medisyncbackend.ObjectIdSerializer;
import com.anubhavauth.medisyncbackend.entities.enums.Roles;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document("patient")
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Patient {
    @Id
    @JsonSerialize(using = ObjectIdSerializer.class)
    private ObjectId id;
    @Indexed(unique = true)
    private String uniqueId;
    private String name;
    private String username;
    private String password;
    private String email;
    private String bloodType;
    private String gender;
    private Integer age;
    private String heightLastMeasured;
    private String weightLastMeasured;
    private String phonePreferred;
    private String phoneAlternate;
    private String address;
    private String city;
    private String state;
    private String zip;
    private String emergencyContact;
    private Roles role;
    private String dob;
    @JsonSerialize(using = ObjectIdSerializer.class)
    private ObjectId medicalDocumentId;
    private String insuranceCompany;
    private String insuranceNo;
    private String insuranceType;
    private String insuranceStatus;
    private String insuranceCompanyNo;
    private String employer;
    private Integer queue = 0;
}