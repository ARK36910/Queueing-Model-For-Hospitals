package com.anubhavauth.medisyncbackend.services;

import com.anubhavauth.medisyncbackend.entities.dtos.PatientDTO;
import com.anubhavauth.medisyncbackend.entities.persistentEntities.Patient;
import com.anubhavauth.medisyncbackend.repository.PatientRepository;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class PatientService {
    private final PatientRepository patientRepository;

    @Autowired
    public PatientService(PatientRepository patientRepository) {
        this.patientRepository = patientRepository;
    }

    public void savePatient(Patient patient) {
        patientRepository.save(patient);
    }

    public Patient loginPatient(PatientDTO patientDTO) {
        Optional<Patient> byId = patientRepository.findPatientByUniqueId(patientDTO.getUniqueId());
        if (byId.isPresent()) {
            Patient patient = byId.get();
            String password = patient.getPassword();
            if (password.equals(patientDTO.getPassword())) {
                return patient;
            }
            throw new RuntimeException("Password does not match");
        }else {
            throw new RuntimeException("Patient not found");
        }
    }

    public Patient getPatientById(ObjectId id) {
        return patientRepository.findById(id).orElseThrow(() -> new RuntimeException("Patient not found"));
    }

}
