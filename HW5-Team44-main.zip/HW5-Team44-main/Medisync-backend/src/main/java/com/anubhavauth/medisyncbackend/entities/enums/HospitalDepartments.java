package com.anubhavauth.medisyncbackend.entities.enums;

public enum HospitalDepartments {
    RECEPTION,
    EMERGENCY,
    SURGERY,
    ICU,
    CARDIOLOGY,
    ONCOLOGY,
    OB_GYN, // Obstetrics and Gynecology
    PEDIATRICS,
    RADIOLOGY,
    NEUROLOGY,
    PSYCHIATRY,
    ORTHOPEDICS,
    GASTROENTEROLOGY,
    DERMATOLOGY,
    ENT, // Ear, Nose, and Throat
    OPHTHALMOLOGY,
    UROLOGY,
    NEPHROLOGY,
    PULMONOLOGY,
    ENDOCRINOLOGY,
    REHABILITATION,
    ANESTHESIOLOGY,
    PATHOLOGY,
    DENTISTRY
}
