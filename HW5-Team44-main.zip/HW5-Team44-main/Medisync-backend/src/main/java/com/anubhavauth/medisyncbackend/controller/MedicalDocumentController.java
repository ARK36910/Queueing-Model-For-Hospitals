package com.anubhavauth.medisyncbackend.controller;

import com.anubhavauth.medisyncbackend.entities.persistentEntities.MedicalDocument;
import com.anubhavauth.medisyncbackend.services.MedicalDocumentService;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/docs")
public class MedicalDocumentController {
    private final MedicalDocumentService medicalDocumentService;

    @Autowired
    public MedicalDocumentController(MedicalDocumentService medicalDocumentService) {
        this.medicalDocumentService = medicalDocumentService;
    }

    @PostMapping("/new")
    public ResponseEntity<String> addDocument(@RequestBody MedicalDocument medicalDocument) {
        medicalDocumentService.add(medicalDocument);
        return ResponseEntity.ok().body("OK");
    }

    @GetMapping("/fetch")
    public ResponseEntity<MedicalDocument> fetchMedicalDocument(@RequestParam ObjectId id) {
        try{
            return new ResponseEntity<>(medicalDocumentService.getDocs(id), HttpStatus.OK);
        }catch (Exception e){
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
