package com.anubhavauth.medisyncbackend.controller;

import com.anubhavauth.medisyncbackend.entities.persistentEntities.Hospital;
import com.anubhavauth.medisyncbackend.services.HospitalService;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/hospital")
public class HospitalController {
    private final HospitalService hospitalService;
    @Autowired
    public HospitalController(HospitalService hospitalService) {
        this.hospitalService = hospitalService;
    }


    @PostMapping("/save")
    public ResponseEntity<String> createHospital(@RequestBody Hospital hospital) {
        hospitalService.saveHospital(hospital);
        return ResponseEntity.ok("Hospital created");
    }

    @GetMapping("/fetch")
    public ResponseEntity<Hospital> getAllHospitals(@RequestParam String regNo) {
        Hospital hospital = hospitalService.getHospital(regNo);
        return ResponseEntity.ok(hospital);
    }
}
