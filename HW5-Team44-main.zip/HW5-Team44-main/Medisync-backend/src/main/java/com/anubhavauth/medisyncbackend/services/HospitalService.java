package com.anubhavauth.medisyncbackend.services;

import com.anubhavauth.medisyncbackend.entities.persistentEntities.Hospital;
import com.anubhavauth.medisyncbackend.repository.HospitalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class HospitalService {
    private final HospitalRepository hospitalRepository;
    @Autowired
    public HospitalService(HospitalRepository hospitalRepository) {
        this.hospitalRepository = hospitalRepository;
    }
    public void saveHospital(Hospital hospital){
        hospitalRepository.save(hospital);
    }

    public Hospital getHospital(String hospitalRegNo) {
        Optional<Hospital> hospitalByHospitalRegNo = hospitalRepository.findHospitalByHospitalRegNo(hospitalRegNo);
        if (hospitalByHospitalRegNo.isPresent()) {
            return hospitalByHospitalRegNo.get();
        }else {
            throw new RuntimeException("Hospital not found");
        }
    }
}
