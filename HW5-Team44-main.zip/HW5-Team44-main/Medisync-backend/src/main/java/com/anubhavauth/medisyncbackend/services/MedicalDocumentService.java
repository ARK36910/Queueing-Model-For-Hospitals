package com.anubhavauth.medisyncbackend.services;

import com.anubhavauth.medisyncbackend.entities.persistentEntities.MedicalDocument;
import com.anubhavauth.medisyncbackend.entities.persistentEntities.Patient;
import com.anubhavauth.medisyncbackend.repository.MedicalDocumentRepository;
import com.anubhavauth.medisyncbackend.repository.PatientRepository;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class MedicalDocumentService {

    private final MedicalDocumentRepository medicalDocumentRepository;
    private final PatientRepository patientRepository;
    @Autowired
    public MedicalDocumentService(MedicalDocumentRepository medicalDocumentRepository, PatientRepository patientRepository) {
        this.medicalDocumentRepository = medicalDocumentRepository;
        this.patientRepository = patientRepository;
    }

    public void add (MedicalDocument medicalDocument) {
        Optional<Patient> byId = patientRepository.findById(medicalDocument.getUserId());
        if (byId.isPresent()) {
            MedicalDocument save = medicalDocumentRepository.save(medicalDocument);
            Patient patient = byId.get();
            patient.setMedicalDocumentId(save.getId());
            patientRepository.save(patient);
        }else {
            throw new RuntimeException("Patient not found");
        }
    }

    public MedicalDocument getDocs(ObjectId id){
        Optional<MedicalDocument> byId = medicalDocumentRepository.findById(id);
        if (byId.isPresent()) {
           return byId.get();
        }else {
            throw new RuntimeException("Docs not found");
        }
    }

}
