package com.anubhavauth.medisyncbackend.controller;

import com.anubhavauth.medisyncbackend.entities.dtos.DoctorDTO;
import com.anubhavauth.medisyncbackend.entities.persistentEntities.Doctor;
import com.anubhavauth.medisyncbackend.repository.DoctorRepository;
import com.anubhavauth.medisyncbackend.services.DoctorService;
import org.apache.coyote.Response;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/doctor")
public class DoctorController {
    private final DoctorService doctorService;

    @Autowired
    public DoctorController(DoctorService doctorService) {
        this.doctorService = doctorService;
    }


    @PostMapping("/new")
    public ResponseEntity<String> createDoctor(@RequestBody Doctor doctor) {
        doctorService.createDoctor(doctor);
        return ResponseEntity.ok("Doctor created");
    }

    @GetMapping("/getAll")
    public ResponseEntity<List<Doctor>> getAllDoctors() {
        return ResponseEntity.ok(doctorService.getAllDoctors());
    }


    @PostMapping("/get-by-id")
    public ResponseEntity<List<Doctor>> getDoctorById(@RequestBody List<ObjectId> doctorIds) {
        List<Doctor> allDoctorsbyId = doctorService.getAllDoctorsbyId(doctorIds);
        return ResponseEntity.ok(allDoctorsbyId);
    }

    @PostMapping("/login")
    public ResponseEntity<Doctor> login(@RequestBody DoctorDTO loginDoctorDTO) {
        Doctor doctor = doctorService.doctorLogin(loginDoctorDTO.getUsername(), loginDoctorDTO.getPassword());
        return ResponseEntity.ok(doctor);
    }
}

