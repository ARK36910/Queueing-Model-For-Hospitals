import React from "react";
import LoginPage from "./Components/Login/LoginPage";

const App = () => {
  const handleLogin = (credentials) => {
    const requestBody = JSON.stringify({
      username: credentials.userID,
      password: credentials.password,
    });

    fetch('https://mediamedisync-backend-latest.onrender.com/doctor/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: requestBody,
    })
      .then(async (response) => {
        const data = await response.json();
        if (!response.ok) {
          throw new Error(`Error ${response.status}: ${data.message || 'Login failed'}`);
        }
        console.log('Success:', data);
        window.location.href = "/home";
      })
      .catch(error => {
        console.error('Error:', error);
      });
  };

  return (
    <div>
      <LoginPage onLogin={handleLogin} />
    </div>
  );
};

export default App;
