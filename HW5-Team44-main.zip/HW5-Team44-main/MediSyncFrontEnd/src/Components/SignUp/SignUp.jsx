import React, { useState } from "react";
import './sign.css';

const SignUpPage = ({ onSignup }) => {
  const [userInfo, setUserInfo] = useState({
    userID: "",
    password: "",
    confirmPassword: "",
  });

  const handleChange = (e) => {
    setUserInfo({ ...userInfo, [e.target.name]: e.target.value });
  };

  const handleSignup = (e) => {
    e.preventDefault();
    if (userInfo.password === userInfo.confirmPassword) {
      onSignup(userInfo);
    } else {
      alert("Passwords do not match");
    }
  };

  return (
    <div className="container">
      <div className="left-panel">
        <div className="content">
          <h1>Hi there!</h1>
          <p>Welcome to our Community!</p>
          <form onSubmit={handleSignup}>
            <input
              type="text"
              name="userID"
              placeholder="Your UserID"
              value={userInfo.userID}
              onChange={handleChange}
              className="input-field"
              required
              aria-required="true"
            />
            <input
              type="password"
              name="password"
              placeholder="Password"
              value={userInfo.password}
              onChange={handleChange}
              className="input-field"
              required
              aria-required="true"
            />
            <input
              type="password"
              name="confirmPassword"
              placeholder="Confirm Password"
              value={userInfo.confirmPassword}
              onChange={handleChange}
              className="input-field"
              required
              aria-required="true"
            />
            <button
              type="submit"
              className="login-button"
            >
              Sign Up
            </button>
          </form>
          <p className="signup-link">
            Already have an account? <a href="/" className="link">Login</a>
          </p>
        </div>
      </div>
      <div className="right-panel">
        <div className="overlay">
          MediSync
        </div>
      </div>
    </div>
  );
};  

export default SignUpPage