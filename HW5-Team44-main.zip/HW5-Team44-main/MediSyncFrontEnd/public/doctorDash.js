document.addEventListener('DOMContentLoaded', function() {
    const patientButtons = document.querySelectorAll('.patient-button');
    const overlay = document.getElementById('patient-panel-overlay');
    const closeBtn = document.querySelector('.close-btn');
    const patientInfo = document.getElementById('patient-info');
    const documentsList = document.getElementById('documents-list');
    const documentContent = document.getElementById('document-content');

  
    patientButtons.forEach(button => {
        button.addEventListener('click', function() {
           
            const randomId = Math.floor(Math.random() * 10000);
            const patient = {
                name: `${this.textContent} (ID: ${randomId})`,
                age: Math.floor(Math.random() * 50) + 20,
                gender: Math.random() > 0.5 ? 'Male' : 'Female',
                documents: ['Medical History', 'Lab Results', 'Prescription']
            };

            patientInfo.innerHTML = `
                <p>Name: ${patient.name}</p>
                <p>Age: ${patient.age}</p>
                <p>Gender: ${patient.gender}</p>
            `;

            documentsList.innerHTML = '';

         
            patient.documents.forEach(doc => {
                const li = document.createElement('li');
                li.textContent = doc;
                li.addEventListener('click', () => {
                    documentContent.innerHTML = `<p>Content of ${doc}</p>`;
                });
                documentsList.appendChild(li);
            });

         
            overlay.style.display = 'block';
        });
    });

  
    closeBtn.addEventListener('click', function() {
        overlay.style.display = 'none';
    });
 


    overlay.addEventListener('click', function(e) {
        if (e.target === overlay) {
            overlay.style.display = 'none';
        }
    });
});
