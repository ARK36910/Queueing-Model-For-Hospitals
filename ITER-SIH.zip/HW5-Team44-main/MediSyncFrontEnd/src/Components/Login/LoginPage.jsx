
import React, { useState } from "react";
import '/src/Components/Login/login.css'

const LoginPage = ({ onLogin }) => {
  const [credentials, setCredentials] = useState({
    userID: "",
    password: "",
  });
  const [errorMessage, setErrorMessage] = useState("");

  const handleChange = (e) => {
    setCredentials({ ...credentials, [e.target.name]: e.target.value });
  };

  const handleLogin = (e) => {
    e.preventDefault();

    const requestBody = JSON.stringify({
      username: credentials.userID,
      password: credentials.password,
    });

    fetch('https://mediamedisync-backend-latest.onrender.com/doctor/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: requestBody,
    })
      .then(async (response) => {
        const data = await response.json();
        if (!response.ok) {
          throw new Error(`Error ${response.status}: ${data.message || 'Login failed'}`);
        }
        console.log('Login successful:', data);
        window.location.href = "./public/doctorDash.html"; 
        setErrorMessage(""); 
        onLogin(credentials); 
      })
      .catch(error => {
        console.error('Login failed:', error);
        setErrorMessage("Login failed: Incorrect username or password.");
      });
  };

  return (
    <div className="container">
      <div className="left-panel">
        <div className="content">
        <h1>M</h1><span>EDI</span><h1>S</h1><span>YNC</span>
          <h2>Welcome Back!</h2>
          <form onSubmit={handleLogin}>
            <input
              type="text"
              name="userID"
              placeholder="Your UserID"
              value={credentials.userID}
              onChange={handleChange}
              className="input-field"
              required
            />
            <input
              type="password"
              name="password"
              placeholder="Password"
              value={credentials.password}
              onChange={handleChange}
              className="input-field"
              required
            />
            <button
              type="submit"
              className="login-button"
            >
              Log In
            </button>
          </form>
          {errorMessage && <div className="error-message">{errorMessage}</div>}
        </div>
      </div>
      <div className="right-panel">
        <div className="overlay"></div>
      </div>
    </div>
  );
};

export default LoginPage;