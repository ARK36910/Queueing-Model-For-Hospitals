document.addEventListener('DOMContentLoaded', function () {
    async function fetchDoctors() {
        try {
            const response = await fetch('https://mediamedisync-backend-latest.onrender.com/doctor/getAll');
            const data = await response.json();
            console.log('Fetched doctors data:', data);
            return data;
        } catch (error) {
            console.error('Error fetching doctors:', error);
            return null;
        }
    }

    async function fetchAppointment(appointmentId) {
        try {
            const response = await fetch(`https://mediamedisync-backend-latest.onrender.com/appointment/fetch?id=${appointmentId}`);
            const data = await response.json();
            console.log('Fetched appointment data:', data);
            return data;
        } catch (error) {
            console.error('Error fetching appointment:', error);
            return null;
        }
    }

    async function fetchPatient(patientId) {
        try {
            const response = await fetch(`https://mediamedisync-backend-latest.onrender.com/patient/fetch?id=${patientId}`);
            const data = await response.json();
            console.log('Fetched patient data:', data);
            return data;
        } catch (error) {
            console.error('Error fetching patient:', error);
            return null;
        }
    }

    function organizeDoctorsByDepartment(doctorsData) {
        const departments = {};
        doctorsData.forEach(doctor => {
            const department = doctor.department.charAt(0) + doctor.department.slice(1).toLowerCase();
            if (!departments[department]) {
                departments[department] = [];
            }
            departments[department].push(doctor.name);
        });
        return departments;
    }

    function populateDepartmentDropdown() {
        const departmentSelects = [
            document.getElementById('emergencyDepartmentSelect')
        ];

        departmentSelects.forEach(select => {
            select.innerHTML = '<option value="">Select Department</option>';
            for (let department in window.departments) {
                const option = document.createElement('option');
                option.value = department;
                option.textContent = department;
                select.appendChild(option);
            }
        });
    }

    function populateDoctorDropdown(departmentSelectId, doctorSelectId) {
        const departmentSelect = document.getElementById(departmentSelectId);
        const doctorSelect = document.getElementById(doctorSelectId);

        departmentSelect.addEventListener('change', function () {
            const department = this.value;
            doctorSelect.innerHTML = '<option value="">Select Doctor</option>';

            if (window.departments[department]) {
                window.departments[department].forEach(doctor => {
                    const option = document.createElement('option');
                    option.value = doctor;
                    option.textContent = doctor;
                    doctorSelect.appendChild(option);
                });
            }
        });
    }

    function addEmergencyPatientToList(name, id) {
        const emergencyList = document.getElementById('emergencies');
        const li = document.createElement('li');
        li.textContent = `${name} (ID: ${id})`;
        emergencyList.appendChild(li);
    }

    async function populatePatientList(doctorsData) {
        const patientList = document.getElementById('patients');
        patientList.innerHTML = '';


        const patientPromises = [];
        for (const doctor of doctorsData) {
            for (const appointmentId of doctor.currentAppointments) {
                patientPromises.push(fetchAppointment(appointmentId));
            }
        }


        const appointments = await Promise.all(patientPromises);


        const patientIds = appointments.map(appointment => appointment.patientId);
        const uniquePatientIds = [...new Set(patientIds)];

        const patientDetailsPromises = uniquePatientIds.map(patientId => fetchPatient(patientId));
        const patients = await Promise.all(patientDetailsPromises);

        patients.forEach(patient => {
            const li = document.createElement('li');
            li.textContent = patient.name;
            patientList.appendChild(li);
        });
    }

    async function initApp() {
        const doctorsData = await fetchDoctors();
        if (doctorsData) {
            window.departments = organizeDoctorsByDepartment(doctorsData);
            populatePatientList(doctorsData);
        } else {
            console.error('Failed to fetch doctors data. Using fallback data.');
            window.departments = {
                "Cardiology": ["Dr. Arun Patel"],
                "Pediatrics": ["Dr. Priya Desai"],
                "Surgery": ["Dr. Anil Kumar"],
                "Dermatology": ["Dr. Neeta Sharma"],
                "Orthopedics": ["Dr. Rajesh Gupta"]
            };
            populatePatientList([]);
        }

        updateDepartmentList();
        populateDepartmentDropdown();
        populateDoctorDropdown('emergencyDepartmentSelect', 'emergencyDoctorName');
    }

    function updateDepartmentList() {
        const departmentList = document.getElementById('departmentList');
        const ul = departmentList.querySelector('ul');
        ul.innerHTML = '';

        for (let department in window.departments) {
            const li = document.createElement('li');
            li.textContent = department;
            li.setAttribute('data-department', department);
            ul.appendChild(li);
        }

        attachDepartmentListeners();
    }

    function attachDepartmentListeners() {
        document.querySelectorAll('#departmentList li').forEach(li => {
            li.addEventListener('click', function () {
                const department = this.getAttribute('data-department');
                updateDoctorList(department);

                document.getElementById('dropdown').style.display = 'none';
            });
        });
    }

    function updateDoctorList(department) {
        const departmentList = document.getElementById('departmentList');
        const selectedDepartment = departmentList.querySelector(`li[data-department="${department}"]`);

        if (selectedDepartment) {
            let doctorDropdown = selectedDepartment.querySelector('.doctor-dropdown');

            if (!doctorDropdown) {
                doctorDropdown = document.createElement('ul');
                doctorDropdown.className = 'doctor-dropdown';
                selectedDepartment.appendChild(doctorDropdown);
            }

            if (doctorDropdown.style.display === 'block') {
                doctorDropdown.style.display = 'none';
            } else {
                doctorDropdown.style.display = 'block';
                doctorDropdown.innerHTML = '';

                if (window.departments[department]) {
                    window.departments[department].forEach(doctor => {
                        const li = document.createElement('li');
                        li.textContent = doctor;
                        doctorDropdown.appendChild(li);
                    });
                } else {
                    console.error('No doctors found for this department.');
                }
            }
        } else {
            console.error('Selected department list item not found.');
        }
    }

    document.getElementById('menu').addEventListener('click', function () {
        const dropdown = document.getElementById('dropdown');
        dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
    });

    document.getElementById('addEmergencyPatientButton').addEventListener('click', function () {
        document.getElementById('emergencyOverlay').style.display = 'flex';
    });

    document.getElementById('closeEmergencyPanel').addEventListener('click', function () {
        document.getElementById('emergencyOverlay').style.display = 'none';
    });

    document.getElementById('emergencyForm').addEventListener('submit', function (event) {
        event.preventDefault();

        const emergencyPatientName = document.getElementById('emergencyPatientName').value;
        const emergencyPatientId = document.getElementById('emergencyPatientId').value;

        addEmergencyPatientToList(emergencyPatientName, emergencyPatientId);
        document.getElementById('emergencyOverlay').style.display = 'none';
        this.reset();
    });

    initApp();
});
