package com.anubhavauth.medisyncbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedisyncBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(MedisyncBackendApplication.class, args);
    }

}
