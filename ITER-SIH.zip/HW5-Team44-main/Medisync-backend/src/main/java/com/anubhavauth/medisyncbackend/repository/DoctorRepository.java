package com.anubhavauth.medisyncbackend.repository;


import com.anubhavauth.medisyncbackend.entities.persistentEntities.Doctor;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

import javax.print.Doc;
import java.util.Optional;

public interface DoctorRepository extends MongoRepository<Doctor, ObjectId> {
    Optional<Doctor> findDoctorByUsername(String username);
}
