package com.anubhavauth.medisyncbackend.controller;


import com.anubhavauth.medisyncbackend.entities.dtos.StaffDTO;
import com.anubhavauth.medisyncbackend.entities.persistentEntities.Hospital;
import com.anubhavauth.medisyncbackend.entities.persistentEntities.Staff;
import com.anubhavauth.medisyncbackend.services.StaffService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/staff")
@CrossOrigin(origins = "*")
public class StaffController {

    private final StaffService staffService;
    @Autowired
    public StaffController(StaffService staffService) {
        this.staffService = staffService;
    }

    @PostMapping("/save")
    public ResponseEntity<String> createStaff(@RequestBody Staff staff) {
        staffService.create(staff);
        return new ResponseEntity<>("Staff Created", HttpStatus.OK);
    }

    @PostMapping("/login")
    public Hospital login(@RequestBody StaffDTO staff) {
        return staffService.staffLogin(staff.getUsername(), staff.getPassword());
    }

}
