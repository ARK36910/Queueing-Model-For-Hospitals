package com.anubhavauth.medisyncbackend.entities.persistentEntities;

import com.anubhavauth.medisyncbackend.ObjectIdSerializer;
import com.anubhavauth.medisyncbackend.entities.enums.Roles;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document("staff")
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Staff {
    @Id
    @JsonSerialize(using = ObjectIdSerializer.class)
    private ObjectId id;
    private String name;
    @Indexed(unique = true)
    private String username;
    private String password;
    private String hospitalReg;
    private String email;
    private String phone;
    private Roles role;
}

