package com.anubhavauth.medisyncbackend.controller;


import com.anubhavauth.medisyncbackend.entities.dtos.PatientDTO;
import com.anubhavauth.medisyncbackend.entities.persistentEntities.Patient;
import com.anubhavauth.medisyncbackend.repository.PatientRepository;
import com.anubhavauth.medisyncbackend.services.PatientService;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/patient")
public class PatientController {

    private final PatientService patientService;
    private final PatientRepository patientRepository;

    @Autowired
    public PatientController(PatientService patientService, PatientRepository patientRepository) {
        this.patientService = patientService;
        this.patientRepository = patientRepository;
    }

    @PostMapping("/save")
    public ResponseEntity<String> save(@RequestBody Patient patient) {
        patientService.savePatient(patient);
        return new ResponseEntity<>("done", HttpStatus.OK);
    }

    @PostMapping("/login")
    public ResponseEntity<Patient> login(@RequestBody PatientDTO patientDTO) {
        try{
            Patient patient = patientService.loginPatient(patientDTO);
            return new ResponseEntity<>(patient, HttpStatus.OK);
        }catch (Exception e){
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/fetch")
    public ResponseEntity<Patient> fetchPatients(@RequestParam ObjectId id) {
        return new ResponseEntity<>(patientService.getPatientById(id), HttpStatus.OK);
    }

}
