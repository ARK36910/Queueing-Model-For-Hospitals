package com.anubhavauth.medisyncbackend.repository;

import com.anubhavauth.medisyncbackend.entities.persistentEntities.Staff;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface StaffRepository extends MongoRepository<Staff, ObjectId> {

    Optional<Staff> findByUsername(String username);

}
