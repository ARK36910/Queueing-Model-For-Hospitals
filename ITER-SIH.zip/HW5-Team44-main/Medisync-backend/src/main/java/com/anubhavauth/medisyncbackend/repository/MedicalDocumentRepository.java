package com.anubhavauth.medisyncbackend.repository;

import com.anubhavauth.medisyncbackend.entities.persistentEntities.MedicalDocument;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface MedicalDocumentRepository extends MongoRepository<MedicalDocument, ObjectId> {
}
