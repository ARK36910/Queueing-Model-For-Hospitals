package com.anubhavauth.medisyncbackend.services;

import com.anubhavauth.medisyncbackend.entities.persistentEntities.Hospital;
import com.anubhavauth.medisyncbackend.entities.persistentEntities.Staff;
import com.anubhavauth.medisyncbackend.repository.HospitalRepository;
import com.anubhavauth.medisyncbackend.repository.StaffRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class StaffService {
    private final StaffRepository staffRepository;
    private final HospitalRepository hospitalRepository;

    @Autowired
    public StaffService(StaffRepository staffRepository, HospitalRepository hospitalRepository) {
        this.staffRepository = staffRepository;
        this.hospitalRepository = hospitalRepository;
    }

    public void create(Staff staff) {
        staffRepository.save(staff);
    }

    public Hospital staffLogin(String username, String password) {
        Optional<Staff> byUsername = staffRepository.findByUsername(username);
        if (byUsername.isPresent()) {
            Staff staff = byUsername.get();
            if (staff.getPassword().equals(password)) {
                Optional<Hospital> hospitalByHospitalRegNo = hospitalRepository.findHospitalByHospitalRegNo(staff.getHospitalReg());
                if (hospitalByHospitalRegNo.isPresent()) {
                    return hospitalByHospitalRegNo.get();
                }
                throw new RuntimeException("Hospital not found");
            }
            throw new RuntimeException("Incorrect password");
        }
        throw new RuntimeException("Staff not found");
    }
}
