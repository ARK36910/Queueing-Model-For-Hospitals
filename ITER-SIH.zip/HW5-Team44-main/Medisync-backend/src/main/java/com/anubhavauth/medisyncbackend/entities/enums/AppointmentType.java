package com.anubhavauth.medisyncbackend.entities.enums;

public enum AppointmentType {
    SELF,
    RECOMMENDATION
}
