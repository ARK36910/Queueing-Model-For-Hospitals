package com.anubhavauth.medisyncbackend.entities.persistentEntities;


import com.anubhavauth.medisyncbackend.ObjectIdSerializer;
import com.anubhavauth.medisyncbackend.entities.enums.HospitalDepartments;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.DayOfWeek;
import java.util.List;
import java.util.Map;

@Document("hospital")
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Hospital {
    @Id
    @JsonSerialize(using = ObjectIdSerializer.class)
    private ObjectId id;
    @Indexed(unique = true)
    private String hospitalRegNo;
    private String name;
    private String address;
    private String city;
    private String state;
    private String zip;
    private Integer noOfBeds;
    @JsonSerialize(contentUsing = ObjectIdSerializer.class)
    private List<ObjectId> admissionQueue;
    @JsonSerialize(contentUsing = ObjectIdSerializer.class)
    private List<ObjectId> opdQueue;
    private List<Map<HospitalDepartments,List<String>>> phoneNumbers;
    private String email;
    private List<Map<ObjectId, List<Map<DayOfWeek,String>>>> doctorsAvailable;
}
