package com.anubhavauth.medisyncbackend.services;

import com.anubhavauth.medisyncbackend.entities.persistentEntities.Appointments;
import com.anubhavauth.medisyncbackend.entities.persistentEntities.Doctor;
import com.anubhavauth.medisyncbackend.entities.persistentEntities.Hospital;
import com.anubhavauth.medisyncbackend.repository.AppointmentRepository;
import com.anubhavauth.medisyncbackend.repository.DoctorRepository;
import com.anubhavauth.medisyncbackend.repository.HospitalRepository;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AppointmentsService {
    private final AppointmentRepository appointmentRepository;
    private final DoctorRepository doctorRepository;
    private final HospitalRepository hospitalRepository;

    @Autowired
    public AppointmentsService(AppointmentRepository appointmentRepository, DoctorRepository doctorRepository, HospitalRepository hospitalRepository) {
        this.appointmentRepository = appointmentRepository;
        this.doctorRepository = doctorRepository;
        this.hospitalRepository = hospitalRepository;
    }

    public void createAppointment(Appointments appointment) {
        Optional<Doctor> doctorById = doctorRepository.findById(appointment.getDoctorId());
        Optional<Hospital> hospitalById = hospitalRepository.findById(appointment.getHospitalId());

        if (doctorById.isPresent() && hospitalById.isPresent()) {
            Appointments save = appointmentRepository.save(appointment);
            Doctor doctor = doctorById.get();
            Hospital hospital = hospitalById.get();

            hospital.getOpdQueue().add(save.getId());
            doctor.getCurrentAppointments().add(appointment.getId());
            hospitalRepository.save(hospital);
            doctorRepository.save(doctor);
        }
    }

    public Appointments fetchAppointments(ObjectId id) {
        Optional<Appointments> byId = appointmentRepository.findById(id);
        if (byId.isPresent()) {
            Appointments appointments = byId.get();
            return appointments;
        }else {
            throw new RuntimeException("No appointments found with id " + id);
        }
    }

}
