package com.anubhavauth.medisyncbackend.repository;

import com.anubhavauth.medisyncbackend.entities.persistentEntities.Hospital;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface HospitalRepository extends MongoRepository<Hospital, ObjectId> {

    Optional<Hospital> findHospitalByHospitalRegNo(String hospitalRegNo);
}
