package com.anubhavauth.medisyncbackend.entities.dtos;

import com.anubhavauth.medisyncbackend.entities.enums.Roles;
import lombok.Data;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;


@Data

public class PatientDTO {
    private String uniqueId;
    private String password;
    private Integer queue = 0;
}
