package com.anubhavauth.medisyncbackend.controller;

import com.anubhavauth.medisyncbackend.entities.persistentEntities.Appointments;
import com.anubhavauth.medisyncbackend.repository.AppointmentRepository;
import com.anubhavauth.medisyncbackend.services.AppointmentsService;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/appointment")
public class AppointmentController {
    private final AppointmentsService appointmentsService;

    @Autowired
    public AppointmentController(AppointmentsService appointmentsService) {
        this.appointmentsService = appointmentsService;
    }

    @PostMapping("/book")
    public ResponseEntity<String> bookAppointment(@RequestBody Appointments appointments) {
        appointmentsService.createAppointment(appointments);
        return ResponseEntity.ok("Appointment booked");
    }

    @GetMapping("/fetch")
    public ResponseEntity<Appointments> fetchAppointments(@RequestParam ObjectId id) {
        Appointments appointments = appointmentsService.fetchAppointments(id);
        return new ResponseEntity<>(appointments, HttpStatus.OK);
    }
}