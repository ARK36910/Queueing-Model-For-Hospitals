package com.anubhavauth.medisyncbackend.repository;

import com.anubhavauth.medisyncbackend.entities.persistentEntities.Patient;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface PatientRepository extends MongoRepository<Patient, ObjectId> {
    Optional<Patient> findPatientByUniqueId(String uniqueId);
}
