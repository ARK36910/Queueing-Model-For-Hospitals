package com.anubhavauth.medisyncbackend.services;

import com.anubhavauth.medisyncbackend.entities.persistentEntities.Doctor;
import com.anubhavauth.medisyncbackend.entities.persistentEntities.Hospital;
import com.anubhavauth.medisyncbackend.repository.DoctorRepository;
import com.anubhavauth.medisyncbackend.repository.HospitalRepository;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class DoctorService {

    private final DoctorRepository doctorRepository;
    private final HospitalRepository hospitalRepository;
    @Autowired
    public DoctorService(DoctorRepository doctorRepository, HospitalRepository hospitalRepository) {
        this.doctorRepository = doctorRepository;
        this.hospitalRepository = hospitalRepository;
    }

    public Doctor doctorLogin(String username, String password) {
        Optional<Doctor> doctorByUsername = doctorRepository.findDoctorByUsername(username);
        if (doctorByUsername.isPresent()) {
            Doctor doctor = doctorByUsername.get();
            if (doctor.getPassword().equals(password)) {
                return doctor;
            }
            throw new RuntimeException("Password Incorrect");
        }
        throw new RuntimeException("Username Incorrect");
    }

    public void createDoctor(Doctor doctor) {
        Doctor save = doctorRepository.save(doctor);

        Optional<Hospital> hospitalByHospitalRegNo = hospitalRepository.findHospitalByHospitalRegNo("HOSP123456");
        if (hospitalByHospitalRegNo.isPresent()) {
            Hospital hospital = hospitalByHospitalRegNo.get();
            hospital.getDoctorsAvailable().add(Map.of(save.getId(), save.getAvailableAppointments()));
            hospitalRepository.save(hospital);
        }

    }

    public List<Doctor> getAllDoctors() {
        return doctorRepository.findAll();
    }


    public List<Doctor> getAllDoctorsbyId(List<ObjectId> ids) {
        return doctorRepository.findAllById(ids);
    }
}
